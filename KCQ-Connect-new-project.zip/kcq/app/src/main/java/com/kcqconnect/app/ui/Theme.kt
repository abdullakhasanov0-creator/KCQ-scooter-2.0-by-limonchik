package com.kcqconnect.app.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val title: String) {
    SYSTEM("Как в системе"), LIGHT("Светлая"), DARK("Тёмная")
}

object ThemeState {
    var mode by mutableStateOf(ThemeMode.SYSTEM)
    var systemDark by mutableStateOf(true)
    val dark: Boolean
        get() = when (mode) {
            ThemeMode.DARK -> true
            ThemeMode.LIGHT -> false
            ThemeMode.SYSTEM -> systemDark
        }

    private fun prefs(c: Context) = c.getSharedPreferences("kcq", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val n = prefs(c).getString("theme", null)
        mode = ThemeMode.values().firstOrNull { it.name == n } ?: ThemeMode.SYSTEM
    }

    fun set(c: Context, m: ThemeMode) {
        mode = m
        prefs(c).edit().putString("theme", m.name).apply()
    }
}

// Цвета читаются из состояния темы, поэтому весь UI перекрашивается сам.
val Cyan: Color get() = if (ThemeState.dark) Color(0xFF00D4FF) else Color(0xFF006E96)
val Graphite: Color get() = if (ThemeState.dark) Color(0xFF161A20) else Color(0xFFFFFFFF)
val GraphiteLight: Color get() = if (ThemeState.dark) Color(0xFF232932) else Color(0xFFE6ECF2)
val Ok = Color(0xFF35D07F)
val Warn = Color(0xFFE59A1F)
val Bad = Color(0xFFFF5C5C)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF00D4FF), onPrimary = Color.Black,
    background = Color(0xFF0B0D10), onBackground = Color(0xFFF2F5F7),
    surface = Color(0xFF161A20), onSurface = Color(0xFFF2F5F7),
    surfaceVariant = Color(0xFF232932), onSurfaceVariant = Color(0xFF9AA5B1),
    secondary = Color(0xFF00D4FF), error = Bad
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF006E96), onPrimary = Color.White,
    background = Color(0xFFF3F6F9), onBackground = Color(0xFF11161B),
    surface = Color.White, onSurface = Color(0xFF11161B),
    surfaceVariant = Color(0xFFE6ECF2), onSurfaceVariant = Color(0xFF55606C),
    secondary = Color(0xFF006E96), error = Bad
)

@Composable
fun KcqTheme(content: @Composable () -> Unit) {
    ThemeState.systemDark = isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (ThemeState.dark) DarkScheme else LightScheme, content = content)
}

package com.kcqconnect.app.diagnostics

import com.kcqconnect.app.bluetooth.ConnectionState
import com.kcqconnect.app.bluetooth.ServiceInfo
import com.kcqconnect.app.protocol.Telemetry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DiagnosticsSnapshot(
    val appVersion: String,
    val androidInfo: String,
    val btSupported: Boolean,
    val btEnabled: Boolean,
    val connState: ConnectionState,
    val deviceName: String?,
    val address: String?,
    val adapterName: String?,
    val services: List<ServiceInfo>,
    val lastRaw: String?,
    val lastDataTime: Long?,
    val packetCount: Int,
    val telemetry: Telemetry?,
    val lastError: String?,
    val log: List<String>
)

object ReportBuilder {
    private fun time(ms: Long?): String =
        if (ms == null) "Нет данных"
        else SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    fun build(s: DiagnosticsSnapshot): String = buildString {
        appendLine("KCQ CONNECT — диагностический отчёт")
        appendLine("Создан: ${time(System.currentTimeMillis())}")
        appendLine("Приложение: ${s.appVersion}")
        appendLine("Устройство: ${s.androidInfo}")
        appendLine()
        appendLine("== Состояние ==")
        appendLine("BLE поддерживается: ${if (s.btSupported) "да" else "нет"}")
        appendLine("Bluetooth включён: ${if (s.btEnabled) "да" else "нет"}")
        appendLine("Подключение: ${s.connState}")
        appendLine("Самокат: ${s.deviceName ?: "Нет данных"} / ${s.address ?: "Нет данных"}")
        appendLine("Адаптер протокола: ${s.adapterName ?: "не распознан"}")
        appendLine("Последняя ошибка: ${s.lastError ?: "нет"}")
        appendLine("Последний пакет: ${time(s.lastDataTime)}")
        appendLine("Принято пакетов: ${s.packetCount}")
        appendLine("Последний пакет (hex): ${s.lastRaw ?: "Нет данных"}")
        appendLine()
        appendLine("== Декодированные значения (масштаб ÷10 — предположение) ==")
        val t = s.telemetry
        if (t == null) {
            appendLine("Нет данных")
        } else {
            appendLine("Скорость: ${t.speedKmh} км/ч")
            appendLine("Пробег поездки: ${t.tripKm} км")
            appendLine("Общий пробег: ${t.totalKm} км")
            appendLine("Заряд: ${t.batteryPercent ?: "Нет данных"} %")
            appendLine("Байт 9 (ошибки): 0x${String.format("%02X", t.faultByte)}")
            appendLine("Байт 10 (статус): 0x${String.format("%02X", t.statusByte)}")
        }
        appendLine()
        appendLine("== BLE-сервисы и характеристики ==")
        if (s.services.isEmpty()) appendLine("Нет данных")
        s.services.forEach { svc ->
            appendLine("Сервис ${svc.uuid}")
            svc.characteristics.forEach { c ->
                val flags = buildList {
                    if (c.canRead) add("READ")
                    if (c.canWrite) add("WRITE")
                    if (c.canNotify) add("NOTIFY")
                    if (c.canIndicate) add("INDICATE")
                }.joinToString(" ")
                appendLine("  ${c.uuid}  [$flags]")
            }
        }
        appendLine()
        appendLine("== Журнал ==")
        s.log.forEach { appendLine(it) }
    }
}

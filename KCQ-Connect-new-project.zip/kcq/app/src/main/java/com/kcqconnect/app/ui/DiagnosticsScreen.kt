package com.kcqconnect.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val NO_DATA = "Нет данных"

@Composable
fun DiagnosticsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val conn = vm.connection
    val btOn by vm.btMonitor.enabled.collectAsState()
    val state by conn.state.collectAsState()
    val services by conn.services.collectAsState()
    val adapterName by conn.adapterName.collectAsState()
    val lastRaw by conn.lastRaw.collectAsState()
    val lastData by conn.lastDataTime.collectAsState()
    val packets by conn.packetCount.collectAsState()
    val telemetry by conn.telemetry.collectAsState()
    val error by conn.error.collectAsState()
    val address by conn.address.collectAsState()
    val logLines by vm.log.entries.collectAsState()
    val now by vm.now.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Диагностика", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Cyan)

        Block("Состояние") {
            Line("BLE на телефоне", if (vm.btMonitor.supported) "есть" else "нет")
            Line("Bluetooth", if (btOn) "включён" else "выключен")
            Line("Подключение", state.name)
            Line("Адрес самоката", address ?: NO_DATA)
            Line("Адаптер протокола", adapterName ?: "не распознан")
            Line("Последняя ошибка", error ?: "нет")
        }

        Block("Данные") {
            Line("Принято пакетов", packets.toString())
            Line("Последний пакет", lastData?.let { "${(now - it) / 1000} с назад" } ?: NO_DATA)
            Line("Сырой пакет", lastRaw ?: NO_DATA)
            val t = telemetry
            Line("Скорость (÷10, не проверено)", t?.let { "${it.speedKmh} км/ч" } ?: NO_DATA)
            Line("Заряд батареи", t?.batteryPercent?.let { "$it %" } ?: NO_DATA)
            Line("Байт ошибок / статуса", t?.let { String.format("0x%02X / 0x%02X", it.faultByte, it.statusByte) } ?: NO_DATA)
        }

        Block("BLE-сервисы и характеристики") {
            if (services.isEmpty()) Text(NO_DATA, color = MaterialTheme.colorScheme.onSurfaceVariant)
            services.forEach { s ->
                Text("Сервис ${s.uuid}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                s.characteristics.forEach { c ->
                    val flags = buildList {
                        if (c.canRead) add("READ")
                        if (c.canWrite) add("WRITE")
                        if (c.canNotify) add("NOTIFY")
                        if (c.canIndicate) add("INDICATE")
                    }.joinToString(" ")
                    Text(
                        "  ${c.uuid}\n  [$flags]",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Block("Журнал (последние 40 записей)") {
            val tail = logLines.takeLast(40)
            if (tail.isEmpty()) Text("Пусто", color = MaterialTheme.colorScheme.onSurfaceVariant)
            tail.forEach {
                Text(it, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Button(
            onClick = {
                val intent = vm.buildReportIntent()
                if (intent != null) {
                    try {
                        context.startActivity(Intent.createChooser(intent, "Отправить отчёт"))
                    } catch (e: ActivityNotFoundException) {
                        vm.log.add("ERROR", "Нет приложения для отправки файла")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = MaterialTheme.colorScheme.onPrimary)
        ) { Text("Экспорт TXT") }

        OutlinedButton(onClick = { vm.log.clear() }, modifier = Modifier.fillMaxWidth()) {
            Text("Очистить журнал")
        }
    }
}

@Composable
private fun Block(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Cyan)
            content()
        }
    }
}

@Composable
private fun Line(label: String, value: String) {
    Column {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp)
    }
}

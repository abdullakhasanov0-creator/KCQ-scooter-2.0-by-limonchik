package com.kcqconnect.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import com.kcqconnect.app.diagnostics.DiagnosticsLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ScannedDevice(val name: String?, val address: String, val rssi: Int)

/** Поиск BLE-устройств. Никуда автоматически не подключается. Вызывать из главного потока. */
class BleScanner(
    private val adapterProvider: () -> BluetoothAdapter?,
    private val log: DiagnosticsLog,
    private val scope: CoroutineScope
) {
    private val found = LinkedHashMap<String, ScannedDevice>()
    private val _devices = MutableStateFlow<List<ScannedDevice>>(emptyList())
    val devices: StateFlow<List<ScannedDevice>> = _devices.asStateFlow()
    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var stopJob: Job? = null
    private var scanner: BluetoothLeScanner? = null
    private var lastEmit = 0L

    private fun publish(force: Boolean) {
        val now = System.currentTimeMillis()
        if (force || now - lastEmit > 700) {
            lastEmit = now
            _devices.value = found.values.sortedByDescending { it.rssi }
        }
    }

    @SuppressLint("MissingPermission")
    private fun safeName(d: BluetoothDevice): String? =
        try {
            d.name
        } catch (e: SecurityException) {
            null
        }

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val address = result.device.address ?: return
            val name = (result.scanRecord?.deviceName ?: safeName(result.device))
                ?.takeIf { it.isNotBlank() }
            found[address] = ScannedDevice(name, address, result.rssi)
            publish(false)
        }

        override fun onScanFailed(errorCode: Int) {
            log.add("ERROR", "Ошибка сканирования, код $errorCode")
            _error.value = "Ошибка сканирования (код $errorCode)"
            _scanning.value = false
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (_scanning.value) return
        val adapter = adapterProvider()
        if (adapter == null || !adapter.isEnabled) {
            _error.value = "Bluetooth выключен"
            return
        }
        val s = adapter.bluetoothLeScanner
        if (s == null) {
            _error.value = "BLE-сканер недоступен"
            return
        }
        found.clear()
        _devices.value = emptyList()
        _error.value = null
        try {
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            s.startScan(null, settings, callback)
            scanner = s
            _scanning.value = true
            log.add("INFO", "Поиск BLE-устройств запущен")
            stopJob = scope.launch {
                delay(SCAN_MS)
                stop()
            }
        } catch (e: SecurityException) {
            log.add("ERROR", "Нет разрешения на сканирование: ${e.message}")
            _error.value = "Нет разрешения на поиск Bluetooth"
        } catch (e: IllegalStateException) {
            log.add("ERROR", "Сканирование не запущено: ${e.message}")
            _error.value = "Не удалось начать поиск"
        }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        stopJob?.cancel()
        stopJob = null
        if (!_scanning.value) return
        try {
            scanner?.stopScan(callback)
        } catch (e: Exception) {
            log.add("WARN", "Остановка сканирования: ${e.message}")
        }
        scanner = null
        _scanning.value = false
        publish(true)
        log.add("INFO", "Поиск остановлен, найдено устройств: ${found.size}")
    }

    private companion object {
        const val SCAN_MS = 15_000L
    }
}

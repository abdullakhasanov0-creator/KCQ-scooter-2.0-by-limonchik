package com.kcqconnect.app.protocol

/**
 * Адаптер по результатам анализа приложения KCQ Scooter 1.5.4 (чтение, без записи):
 *  сервис FFF0, уведомления FFF7.
 *  Пакет: AA 55 | speed(2..3, LE) | total(4..5, LE) | trip(6..7, LE) | battery%(8) | fault(9) | status(10)
 *  Масштаб скорости и пробега (÷10) — предположение, требует проверки на живом самокате.
 */
class KcqFff0Adapter : ScooterAdapter {
    override val id = "kcq-fff0"
    override val displayName = "KCQ (сервис FFF0, уведомления FFF7)"
    override val serviceUuid = uuid16(0xFFF0)
    override val notifyUuid = uuid16(0xFFF7)

    private fun u(b: ByteArray, i: Int) = b[i].toInt() and 0xFF

    override fun decode(bytes: ByteArray): DecodeResult {
        if (bytes.size < 2) return DecodeResult.Ignored("Слишком короткий пакет (${bytes.size} байт)")
        if (u(bytes, 0) != 0xAA || u(bytes, 1) != 0x55) {
            return DecodeResult.Ignored("Не пакет телеметрии (заголовок ${String.format("%02X %02X", bytes[0], bytes[1])})")
        }
        if (bytes.size < 11) return DecodeResult.Error("Пакет AA 55 короче 11 байт (${bytes.size})")

        val speedRaw = u(bytes, 2) or (u(bytes, 3) shl 8)
        val totalRaw = u(bytes, 4) or (u(bytes, 5) shl 8)
        val tripRaw = u(bytes, 6) or (u(bytes, 7) shl 8)
        val battery = u(bytes, 8)

        return DecodeResult.Ok(
            Telemetry(
                speedKmh = speedRaw / SCALE,
                tripKm = tripRaw / SCALE,
                totalKm = totalRaw / SCALE,
                batteryPercent = if (battery in 0..100) battery else null,
                faultByte = u(bytes, 9),
                statusByte = u(bytes, 10)
            )
        )
    }

    companion object {
        const val SCALE = 10.0
    }
}

object AdapterRegistry {
    val all: List<ScooterAdapter> = listOf(KcqFff0Adapter())
}

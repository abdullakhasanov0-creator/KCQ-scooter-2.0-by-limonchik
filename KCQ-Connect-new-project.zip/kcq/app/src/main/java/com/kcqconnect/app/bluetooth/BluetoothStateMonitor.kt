package com.kcqconnect.app.bluetooth

import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Следит за включением/выключением Bluetooth. */
class BluetoothStateMonitor(
    private val context: Context,
    adapter: BluetoothAdapter?
) {
    val supported: Boolean = adapter != null
    private val _enabled = MutableStateFlow(adapter?.isEnabled == true)
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent?.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                val s = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                _enabled.value = s == BluetoothAdapter.STATE_ON
            }
        }
    }

    init {
        ContextCompat.registerReceiver(
            context, receiver,
            IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    fun release() {
        try {
            context.unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
        }
    }
}
